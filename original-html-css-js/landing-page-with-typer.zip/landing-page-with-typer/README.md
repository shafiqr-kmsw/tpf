# Landing Page With Typer

A Pen created on CodePen.io. Original URL: [https://codepen.io/ZaynAlaoudi/pen/RZGxGj](https://codepen.io/ZaynAlaoudi/pen/RZGxGj).

